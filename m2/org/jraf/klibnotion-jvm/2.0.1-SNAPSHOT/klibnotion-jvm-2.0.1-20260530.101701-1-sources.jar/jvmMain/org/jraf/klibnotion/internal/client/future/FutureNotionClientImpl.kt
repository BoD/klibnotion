/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2021-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 * and contributors (https://github.com/BoD/klibnotion/graphs/contributors)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.klibnotion.internal.client.future

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.future.future
import org.jraf.klibnotion.client.NotionClient
import org.jraf.klibnotion.client.future.FutureNotionClient
import org.jraf.klibnotion.model.base.EmojiOrFile
import org.jraf.klibnotion.model.base.UuidString
import org.jraf.klibnotion.model.base.reference.DatabaseReference
import org.jraf.klibnotion.model.base.reference.PageReference
import org.jraf.klibnotion.model.block.Block
import org.jraf.klibnotion.model.block.BlockListProducer
import org.jraf.klibnotion.model.block.MutableBlockList
import org.jraf.klibnotion.model.database.query.DatabaseQuery
import org.jraf.klibnotion.model.file.File
import org.jraf.klibnotion.model.oauth.OAuthCredentials
import org.jraf.klibnotion.model.pagination.Pagination
import org.jraf.klibnotion.model.property.sort.PropertySort
import org.jraf.klibnotion.model.property.spec.PropertySpecList
import org.jraf.klibnotion.model.property.value.PropertyValueList
import org.jraf.klibnotion.model.richtext.RichTextList

internal class FutureNotionClientImpl(
    private val notionClient: NotionClient,
) : FutureNotionClient,
    FutureNotionClient.OAuth,
    FutureNotionClient.Users,
    FutureNotionClient.Databases,
    FutureNotionClient.Pages,
    FutureNotionClient.Blocks,
    FutureNotionClient.Search {

    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override val oAuth = this
    override val users = this
    override val databases = this
    override val pages = this
    override val blocks = this
    override val search = this

    override fun getUser(id: UuidString) = coroutineScope.future {
        notionClient.users.getUser(id)
    }

    override fun getUserList(pagination: Pagination) = coroutineScope.future {
        notionClient.users.getUserList(pagination)
    }

    override fun getDatabase(id: UuidString) = coroutineScope.future {
        notionClient.databases.getDatabase(id)
    }

    @Deprecated("The List Databases endpoint was deprecated by Notion in API version 2022-02-22. Use search.searchDatabases instead.")
    @Suppress("DEPRECATION")
    override fun getDatabaseList(pagination: Pagination) = coroutineScope.future {
        notionClient.databases.getDatabaseList(pagination)
    }

    override fun queryDatabase(
        id: UuidString,
        query: DatabaseQuery?,
        sort: PropertySort?,
        pagination: Pagination,
    ) = coroutineScope.future {
        notionClient.databases.queryDatabase(
            id,
            query,
            sort,
            pagination,
        )
    }

    override fun queryDataSource(
        dataSourceId: UuidString,
        query: DatabaseQuery?,
        sort: PropertySort?,
        pagination: Pagination,
    ) = coroutineScope.future {
        notionClient.databases.queryDataSource(
            dataSourceId,
            query,
            sort,
            pagination,
        )
    }

    override fun createDatabase(
        parentPageId: UuidString,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertySpecList,
    ) = coroutineScope.future {
        notionClient.databases.createDatabase(
            parentPageId = parentPageId,
            title = title,
            icon = icon,
            cover = cover,
            properties = properties,
        )
    }

    override fun updateDatabase(
        id: UuidString,
        title: RichTextList?,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertySpecList?,
    ) =
        coroutineScope.future {
            notionClient.databases.updateDatabase(
                id = id,
                title = title,
                icon = icon,
                cover = cover,
                properties = properties,
            )
        }

    override fun getPage(id: UuidString) = coroutineScope.future {
        notionClient.pages.getPage(id)
    }

    override fun createPage(
        parentDatabase: DatabaseReference,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
        content: MutableBlockList?,
    ) = coroutineScope.future {
        notionClient.pages.createPage(
            parentDatabase = parentDatabase,
            properties = properties,
            content = content,
            icon = icon,
            cover = cover,
        )
    }

    override fun createPage(
        parentDatabase: DatabaseReference,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
        content: BlockListProducer,
    ) = coroutineScope.future {
        notionClient.pages.createPage(
            parentDatabase = parentDatabase,
            properties = properties,
            content = content,
            icon = icon,
            cover = cover,
        )
    }

    override fun createPage(
        parentPage: PageReference,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        content: MutableBlockList?,
    ) = coroutineScope.future {
        notionClient.pages.createPage(
            parentPage = parentPage,
            title = title,
            content = content,
            icon = icon,
            cover = cover,
        )
    }

    override fun createPage(
        parentPage: PageReference,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        content: BlockListProducer,
    ) = coroutineScope.future {
        notionClient.pages.createPage(
            parentPage = parentPage,
            title = title,
            content = content,
            icon = icon,
            cover = cover,
        )
    }

    override fun getUserPromptUri(oAuthCredentials: OAuthCredentials, uniqueState: String) =
        notionClient.oAuth.getUserPromptUri(oAuthCredentials, uniqueState)

    override fun extractCodeAndStateFromRedirectUri(redirectUri: String) =
        notionClient.oAuth.extractCodeAndStateFromRedirectUri(redirectUri)

    override fun getAccessToken(oAuthCredentials: OAuthCredentials, code: String) = coroutineScope.future {
        notionClient.oAuth.getAccessToken(oAuthCredentials, code)
    }

    override fun updatePage(
        id: UuidString,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
    ) = coroutineScope.future {
        notionClient.pages.updatePage(id, icon, cover, properties)
    }

    override fun setPageInTrash(id: UuidString, inTrash: Boolean) = coroutineScope.future {
        notionClient.pages.setPageInTrash(id, inTrash)
    }

    override fun getBlockList(parentId: UuidString, pagination: Pagination) = coroutineScope.future {
        notionClient.blocks.getBlockList(parentId, pagination)
    }

    override fun getAllBlockListRecursively(parentId: UuidString) = coroutineScope.future {
        notionClient.blocks.getAllBlockListRecursively(parentId)
    }

    override fun appendBlockList(parentId: UuidString, afterBlockId: UuidString?, blocks: MutableBlockList) =
        coroutineScope.future<Void?> {
            notionClient.blocks.appendBlockList(parentId, afterBlockId, blocks)
            null
        }

    override fun appendBlockList(parentId: UuidString, afterBlockId: UuidString?, blocks: BlockListProducer) =
        coroutineScope.future<Void?> {
            notionClient.blocks.appendBlockList(parentId, afterBlockId, blocks)
            null
        }

    override fun getBlock(id: UuidString, retrieveChildrenRecursively: Boolean) = coroutineScope.future {
        notionClient.blocks.getBlock(id, retrieveChildrenRecursively)
    }

    override fun updateBlock(id: UuidString, block: Block) = coroutineScope.future {
        notionClient.blocks.updateBlock(id, block)
    }

    override fun searchPages(query: String?, sort: PropertySort?, pagination: Pagination) = coroutineScope.future {
        notionClient.search.searchPages(query, sort, pagination)
    }

    override fun searchDatabases(query: String?, sort: PropertySort?, pagination: Pagination) = coroutineScope.future {
        notionClient.search.searchDatabases(query, sort, pagination)
    }

    override fun close() {
        notionClient.close()
        coroutineScope.cancel()
    }

}
