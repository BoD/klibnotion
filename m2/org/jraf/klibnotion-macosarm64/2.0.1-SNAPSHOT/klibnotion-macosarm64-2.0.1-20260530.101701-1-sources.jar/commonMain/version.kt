// Generated file. Do not edit!
package org.jraf.klibnotion
import kotlin.jvm.JvmField
@JvmField
val VERSION = "2.0.1-SNAPSHOT"
