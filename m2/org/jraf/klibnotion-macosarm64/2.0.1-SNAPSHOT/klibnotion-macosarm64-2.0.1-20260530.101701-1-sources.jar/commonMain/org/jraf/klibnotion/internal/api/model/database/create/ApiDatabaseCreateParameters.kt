/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2021-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 * and contributors (https://github.com/BoD/klibnotion/graphs/contributors)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.klibnotion.internal.api.model.database.create

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import org.jraf.klibnotion.internal.api.model.base.ApiReference
import org.jraf.klibnotion.internal.api.model.property.spec.ApiPropertySpec

/**
 * See [Reference](https://developers.notion.com/reference/create-a-database).
 */
@Serializable
internal data class ApiDatabaseCreateParameters(
    val parent: ApiReference,
    val title: JsonArray,
    val icon: JsonElement? = null,
    val cover: JsonElement? = null,
    // As of API version 2025-09-03, properties are specified under initial_data_source,
    // not at the top level of the database create parameters.
    val initial_data_source: ApiInitialDataSource? = null,
)

@Serializable
internal data class ApiInitialDataSource(
    val properties: Map<String, ApiPropertySpec>? = null,
)
