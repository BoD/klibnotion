/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2021-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 * and contributors (https://github.com/BoD/klibnotion/graphs/contributors)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.klibnotion.internal.api.model.block

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * See [Reference](https://developers.notion.com/reference/patch-block-children).
 */
@Serializable
internal data class ApiAppendBlocksParameters(
    val children: List<JsonElement>,
    val position: ApiAppendBlocksPosition? = null,
)

/**
 * Specifies where to insert appended blocks. As of API version 2026-03-11, this replaces the old `after` parameter.
 * See [Reference](https://developers.notion.com/reference/patch-block-children).
 */
@Serializable
internal data class ApiAppendBlocksPosition(
    val type: String,
    val block_id: String? = null,
)
