/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2021-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 * and contributors (https://github.com/BoD/klibnotion/graphs/contributors)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.klibnotion.internal.client

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.ProxyBuilder
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.HttpResponseValidator
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.HttpTimeoutConfig
import io.ktor.client.plugins.UserAgent
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.plugins.logging.DEFAULT
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.request.HttpRequest
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.ParametersBuilder
import io.ktor.http.URLBuilder
import io.ktor.http.URLProtocol
import io.ktor.http.Url
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json
import org.jraf.klibnotion.client.Authentication
import org.jraf.klibnotion.client.ClientConfiguration
import org.jraf.klibnotion.client.HttpLoggingLevel
import org.jraf.klibnotion.client.NotionClient
import org.jraf.klibnotion.internal.api.model.apiToModel
import org.jraf.klibnotion.internal.api.model.block.ApiAppendBlocksParametersConverter
import org.jraf.klibnotion.internal.api.model.block.ApiInBlockConverter
import org.jraf.klibnotion.internal.api.model.block.ApiOutBlockConverter
import org.jraf.klibnotion.internal.api.model.block.ApiPageResultBlockConverter
import org.jraf.klibnotion.internal.api.model.database.ApiDatabaseConverter
import org.jraf.klibnotion.internal.api.model.database.create.ApiDatabaseCreateParametersConverter
import org.jraf.klibnotion.internal.api.model.database.create.DatabaseCreateParameters
import org.jraf.klibnotion.internal.api.model.database.query.ApiDatabaseQueryConverter
import org.jraf.klibnotion.internal.api.model.database.update.ApiDatabaseUpdateParametersConverter
import org.jraf.klibnotion.internal.api.model.database.update.DatabaseUpdateParameters
import org.jraf.klibnotion.internal.api.model.datasource.ApiDataSourceUpdateParameters
import org.jraf.klibnotion.internal.api.model.modelToApi
import org.jraf.klibnotion.internal.api.model.oauth.ApiOAuthGetAccessTokenParameters
import org.jraf.klibnotion.internal.api.model.oauth.ApiOAuthGetAccessTokenResultConverter
import org.jraf.klibnotion.internal.api.model.page.ApiPageConverter
import org.jraf.klibnotion.internal.api.model.page.ApiPageCreateParametersConverter
import org.jraf.klibnotion.internal.api.model.page.ApiPageResultDatabaseConverter
import org.jraf.klibnotion.internal.api.model.page.ApiPageResultPageConverter
import org.jraf.klibnotion.internal.api.model.page.ApiPageUpdateParametersConverter
import org.jraf.klibnotion.internal.api.model.page.PageCreateParameters
import org.jraf.klibnotion.internal.api.model.page.PageUpdateParameters
import org.jraf.klibnotion.internal.api.model.property.spec.ApiPropertySpecConverter
import org.jraf.klibnotion.internal.api.model.search.ApiSearchParametersConverter
import org.jraf.klibnotion.internal.api.model.search.SearchParameters
import org.jraf.klibnotion.internal.api.model.user.ApiUserConverter
import org.jraf.klibnotion.internal.api.model.user.ApiUserResultPageConverter
import org.jraf.klibnotion.internal.model.block.MutableBlock
import org.jraf.klibnotion.internal.model.oauth.OAuthCodeAndStateImpl
import org.jraf.klibnotion.model.base.EmojiOrFile
import org.jraf.klibnotion.model.base.UuidString
import org.jraf.klibnotion.model.base.reference.DatabaseReference
import org.jraf.klibnotion.model.base.reference.PageReference
import org.jraf.klibnotion.model.block.Block
import org.jraf.klibnotion.model.block.BlockListProducer
import org.jraf.klibnotion.model.block.MutableBlockList
import org.jraf.klibnotion.model.block.invoke
import org.jraf.klibnotion.model.database.Database
import org.jraf.klibnotion.model.database.query.DatabaseQuery
import org.jraf.klibnotion.model.exceptions.NotionClientException
import org.jraf.klibnotion.model.exceptions.NotionClientRequestException
import org.jraf.klibnotion.model.file.File
import org.jraf.klibnotion.model.oauth.OAuthCodeAndState
import org.jraf.klibnotion.model.oauth.OAuthCredentials
import org.jraf.klibnotion.model.oauth.OAuthGetAccessTokenResult
import org.jraf.klibnotion.model.page.Page
import org.jraf.klibnotion.model.pagination.Pagination
import org.jraf.klibnotion.model.pagination.ResultPage
import org.jraf.klibnotion.model.property.sort.PropertySort
import org.jraf.klibnotion.model.property.spec.PropertySpecList
import org.jraf.klibnotion.model.property.value.PropertyValueList
import org.jraf.klibnotion.model.richtext.RichTextList
import org.jraf.klibnotion.model.user.User

internal class NotionClientImpl(
    private var clientConfiguration: ClientConfiguration,
) : NotionClient,
    NotionClient.OAuth,
    NotionClient.Users,
    NotionClient.Databases,
    NotionClient.Pages,
    NotionClient.Blocks,
    NotionClient.Search {

    override val oAuth = this
    override val users = this
    override val databases = this
    override val pages = this
    override val blocks = this
    override val search = this

    private val httpClient by lazy {
        createHttpClient(clientConfiguration.httpConfiguration.bypassSslChecks) {
            install(ContentNegotiation) {
                json(
                    Json {
                        // XXX Comment this to have API changes make the parsing fail
                        ignoreUnknownKeys = true

                        // This is needed to accept JSON Numbers to be deserialized as Strings
                        isLenient = true

                        // This may improve performance
                        // PLUS is a workaround for these issues:
                        // - https://youtrack.jetbrains.com/issue/KTOR-2740
                        // - https://github.com/Kotlin/kotlinx.serialization/issues/1450
                        useAlternativeNames = false

                        // Don't encode fields that have their default value (typically null).
                        // This keeps outgoing request bodies clean: property specs, query filters, etc.
                        // only include the fields that are actually set.
                        encodeDefaults = false
                    },
                )
            }
            defaultRequest {
                if (headers[HttpHeaders.Authorization] == null) {
                    val authentication = clientConfiguration.authentication
                        ?: throw IllegalStateException("You must set the Authentication accessToken before making this call")
                    header(
                        HttpHeaders.Authorization,
                        "Bearer ${authentication.accessToken}"
                    )
                }
                header(HEADER_NOTION_VERSION, NOTION_API_VERSION)
            }
            install(UserAgent) {
                agent = clientConfiguration.userAgent
            }
            // Notion API is very slow, so...
            install(HttpTimeout) {
                requestTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                connectTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                socketTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
            }
            engine {
                // Setup a proxy if requested
                clientConfiguration.httpConfiguration.httpProxy?.let { httpProxy ->
                    proxy = ProxyBuilder.http(URLBuilder().apply {
                        host = httpProxy.host
                        port = httpProxy.port
                    }.build())
                }
            }
            // Setup logging if requested
            if (clientConfiguration.httpConfiguration.loggingLevel != HttpLoggingLevel.NONE) {
                install(Logging) {
                    logger = Logger.DEFAULT
                    level = when (clientConfiguration.httpConfiguration.loggingLevel) {
                        HttpLoggingLevel.NONE -> LogLevel.NONE
                        HttpLoggingLevel.INFO -> LogLevel.INFO
                        HttpLoggingLevel.HEADERS -> LogLevel.HEADERS
                        HttpLoggingLevel.BODY -> LogLevel.BODY
                        HttpLoggingLevel.ALL -> LogLevel.ALL
                    }
                }
            }
            HttpResponseValidator {
                validateResponse { response ->
                    val statusCode = response.status.value
                    if (statusCode >= 400) {
                        // Read the body here, before ContentNegotiation tries to deserialize it as a domain object.
                        val body = response.bodyAsText()
                        throw NotionClientRequestException(ClientRequestException(response, body), body)
                    }
                }
                handleResponseExceptionWithRequest { cause: Throwable, _: HttpRequest ->
                    // Re-throw NotionClientRequestException as-is (already created in validateResponse).
                    if (cause is NotionClientRequestException) throw cause

                    if (cause is ClientRequestException) throw NotionClientRequestException(
                        cause,
                        cause.response.bodyAsText()
                    )

                    if (cause !is CancellationException) throw NotionClientException(cause)
                }
            }
        }
    }

    private val service: NotionService by lazy {
        NotionService(httpClient)
    }

    // region OAuth

    override fun getUserPromptUri(oAuthCredentials: OAuthCredentials, uniqueState: String): String {
        return URLBuilder(protocol = URLProtocol.createOrDefault(NotionService.OAUTH_URL_SCHEME),
            host = NotionService.OAUTH_URL_HOST,
            pathSegments = NotionService.OAUTH_URL_PATH_SEGMENTS,
            parameters = ParametersBuilder().apply {
                append("client_id", oAuthCredentials.clientId)
                append("redirect_uri", oAuthCredentials.redirectUri)
                append("response_type", "code")
                // XXX Adding a _ to ensure it's not interpreted as a number
                append("state", "_$uniqueState")
            }.build()
        ).buildString()
    }

    override fun extractCodeAndStateFromRedirectUri(redirectUri: String): OAuthCodeAndState? {
        return try {
            val url = Url(redirectUri)
            // XXX Removing the _ added in getLoginUri
            val state = url.parameters["state"]!!.removePrefix("_")
            OAuthCodeAndStateImpl(code = url.parameters["code"]!!, state = state)
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun getAccessToken(oAuthCredentials: OAuthCredentials, code: String): OAuthGetAccessTokenResult {
        val accessTokenResult = service.getOAuthAccessToken(
            clientId = oAuthCredentials.clientId,
            clientSecret = oAuthCredentials.clientSecret,
            parameters = ApiOAuthGetAccessTokenParameters(
                grant_type = "authorization_code",
                redirect_uri = oAuthCredentials.redirectUri,
                code = code,
            ),
        )
            .apiToModel(ApiOAuthGetAccessTokenResultConverter)
        clientConfiguration = clientConfiguration.copy(authentication = Authentication(accessTokenResult.accessToken))
        return accessTokenResult
    }

    // endregion


    // region Users

    override suspend fun getUser(id: UuidString): User {
        return service.getUser(id)
            .apiToModel(ApiUserConverter)
    }

    override suspend fun getUserList(pagination: Pagination): ResultPage<User> {
        return service.getUserList(pagination.startCursor)
            .apiToModel(ApiUserResultPageConverter)
    }

    // endregion


    // region Databases

    override suspend fun getDatabase(id: UuidString): Database {
        return service.getDatabase(id)
            .apiToModel(ApiDatabaseConverter)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override suspend fun getDatabaseList(pagination: Pagination): ResultPage<Database> {
        return searchDatabases(pagination = pagination)
    }

    override suspend fun queryDatabase(
        id: UuidString,
        query: DatabaseQuery?,
        sort: PropertySort?,
        pagination: Pagination,
    ): ResultPage<Page> {
        // As of API version 2025-09-03, the query endpoint moved to /v1/data_sources/{id}/query.
        // Fetch the database to obtain the data source ID, then query against it.
        val database = service.getDatabase(id).apiToModel(ApiDatabaseConverter)
        val dataSourceId = database.dataSourceIds.firstOrNull() ?: id
        return queryDataSource(dataSourceId, query, sort, pagination)
    }

    override suspend fun queryDataSource(
        dataSourceId: UuidString,
        query: DatabaseQuery?,
        sort: PropertySort?,
        pagination: Pagination,
    ): ResultPage<Page> {
        return service.queryDataSource(
            dataSourceId,
            Triple(query, sort, pagination).modelToApi(ApiDatabaseQueryConverter),
        )
            .apiToModel(ApiPageResultPageConverter)
    }

    override suspend fun createDatabase(
        parentPageId: UuidString,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertySpecList,
    ): Database {
        return service.createDatabase(
            DatabaseCreateParameters(
                parentPageId = parentPageId,
                title = title,
                icon = icon,
                cover = cover,
                properties = properties,
            ).modelToApi(ApiDatabaseCreateParametersConverter)
        )
            .apiToModel(ApiDatabaseConverter)
    }

    override suspend fun updateDatabase(
        id: UuidString,
        title: RichTextList?,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertySpecList?,
    ): Database {
        // Step 1: Update metadata (title, icon, cover) via the databases endpoint.
        // If none of those are provided we still call getDatabase to retrieve data source IDs (needed for step 2).
        val database = if (title != null || icon != null || cover != null) {
            service.updateDatabase(
                id,
                DatabaseUpdateParameters(
                    title = title,
                    icon = icon,
                    cover = cover,
                    properties = null,
                ).modelToApi(ApiDatabaseUpdateParametersConverter),
            ).apiToModel(ApiDatabaseConverter)
        } else {
            service.getDatabase(id).apiToModel(ApiDatabaseConverter)
        }

        // Step 2: If properties are provided, update the first data source's schema.
        // As of API version 2025-09-03, properties are managed at the data source level.
        if (properties != null) {
            val dataSourceId = database.dataSourceIds.firstOrNull()
            if (dataSourceId != null) {
                service.updateDataSource(
                    dataSourceId,
                    ApiDataSourceUpdateParameters(
                        properties = properties.propertySpecList.modelToApi(ApiPropertySpecConverter).toMap(),
                    ),
                )
            }
        }

        return database
    }

    // endregion


    // region Pages

    override suspend fun getPage(id: UuidString): Page {
        return service.getPage(id)
            .apiToModel(ApiPageConverter)
    }

    override suspend fun createPage(
        parentDatabase: DatabaseReference,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
        content: MutableBlockList?,
    ): Page {
        return service.createPage(
            PageCreateParameters(
                reference = parentDatabase,
                properties = properties.propertyValueList,
                children = content,
                icon = icon,
                cover = cover,
            ).modelToApi(ApiPageCreateParametersConverter)
        )
            .apiToModel(ApiPageConverter)
    }

    override suspend fun createPage(
        parentDatabase: DatabaseReference,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
        content: BlockListProducer,
    ): Page = createPage(
        parentDatabase = parentDatabase,
        properties = properties,
        icon = icon,
        cover = cover,
        content = content(),
    )

    override suspend fun createPage(
        parentPage: PageReference,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        content: MutableBlockList?,
    ): Page {
        return service.createPage(
            PageCreateParameters(
                reference = parentPage,
                properties = PropertyValueList().title("title", title).propertyValueList,
                children = content,
                icon = icon,
                cover = cover
            ).modelToApi(ApiPageCreateParametersConverter)
        )
            .apiToModel(ApiPageConverter)
    }

    override suspend fun createPage(
        parentPage: PageReference,
        title: RichTextList,
        icon: EmojiOrFile?,
        cover: File?,
        content: BlockListProducer,
    ): Page = createPage(
        parentPage = parentPage,
        title = title,
        icon = icon,
        cover = cover,
        content = content(),
    )

    override suspend fun updatePage(
        id: UuidString,
        icon: EmojiOrFile?,
        cover: File?,
        properties: PropertyValueList,
    ): Page {
        return service.updatePage(
            id = id,
            parameters = PageUpdateParameters(
                properties = properties.propertyValueList,
                icon = icon,
                cover = cover,
            ).modelToApi(ApiPageUpdateParametersConverter)
        )
            .apiToModel(ApiPageConverter)
    }

    override suspend fun setPageInTrash(id: UuidString, inTrash: Boolean): Page {
        return service.archivePage(id, inTrash)
            .apiToModel(ApiPageConverter)
    }

    // endregion


    // region Blocks

    override suspend fun getBlockList(parentId: UuidString, pagination: Pagination): ResultPage<Block> {
        return service.getBlockList(parentId, pagination.startCursor)
            .apiToModel(ApiPageResultBlockConverter)
    }

    override suspend fun getAllBlockListRecursively(parentId: UuidString): List<Block> {
        val results = mutableListOf<Block>()
        var nextPagination: Pagination? = Pagination()
        while (nextPagination != null) {
            val blockResultPage = service.getBlockList(parentId, nextPagination.startCursor)
                .apiToModel(ApiPageResultBlockConverter)
            getChildrenRecursively(blockResultPage)
            results += blockResultPage.results
            nextPagination = blockResultPage.nextPagination
        }
        return results
    }

    private suspend fun getChildrenRecursively(blockResultPage: ResultPage<Block>) = coroutineScope {
        blockResultPage.results
            .mapNotNull { block ->
                if (block is MutableBlock && block.children?.isEmpty() == true) {
                    async {
                        val childrenResultPage = getAllBlockListRecursively(block.id)
                        block.children = childrenResultPage
                    }
                } else {
                    null
                }
            }
            .awaitAll()
    }

    override suspend fun appendBlockList(parentId: UuidString, afterBlockId: UuidString?, blocks: MutableBlockList) {
        service.appendBlockList(
            parentId,
            ApiAppendBlocksParametersConverter.modelToApi(blocks, afterBlockId),
        )
    }

    override suspend fun appendBlockList(parentId: UuidString, afterBlockId: UuidString?, blocks: BlockListProducer) =
        appendBlockList(parentId, afterBlockId, blocks() ?: MutableBlockList())

    override suspend fun getBlock(id: UuidString, retrieveChildrenRecursively: Boolean): Block {
        val block = service.getBlock(id)
            .apiToModel(ApiInBlockConverter)
        if (retrieveChildrenRecursively && block.children != null) {
            val children = getAllBlockListRecursively(id)
            (block as MutableBlock).children = children
        }
        return block
    }

    override suspend fun updateBlock(id: UuidString, block: Block): Block {
        return service.updateBlock(id, block.modelToApi(ApiOutBlockConverter))
            .apiToModel(ApiInBlockConverter)
    }

    // endregion


    // region Search

    override suspend fun searchPages(
        query: String?,
        sort: PropertySort?,
        pagination: Pagination,
    ): ResultPage<Page> {
        return service.searchPages(
            parameters = SearchParameters(
                query = query,
                sort = sort,
                type = "page",
                startCursor = pagination.startCursor
            ).modelToApi(ApiSearchParametersConverter),
        )
            .apiToModel(ApiPageResultPageConverter)
    }

    override suspend fun searchDatabases(
        query: String?,
        sort: PropertySort?,
        pagination: Pagination,
    ): ResultPage<Database> {
        return service.searchDatabases(
            parameters = SearchParameters(
                query = query,
                sort = sort,
                type = "data_source",
                startCursor = pagination.startCursor,
            ).modelToApi(ApiSearchParametersConverter),
        )
            .apiToModel(ApiPageResultDatabaseConverter)
    }

    // endregion


    override fun close() = httpClient.close()

    companion object {
        private const val HEADER_NOTION_VERSION = "Notion-Version"
        private const val NOTION_API_VERSION = "2026-03-11"
    }
}

internal expect fun createHttpClient(
    bypassSslChecks: Boolean,
    block: HttpClientConfig<*>.() -> Unit,
): HttpClient
